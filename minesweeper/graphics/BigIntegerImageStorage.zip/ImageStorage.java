package com.javarush.games.minesweeper.graphics;

import com.javarush.engine.cell.Color;

/**
 * All images' body data and colors are stored here. Each image corresponds a visual element.
 */

public class ImageStorage {
    private Color[] colors;
    private final int[][] data;

    public ImageStorage(VisualElement visualElement) {
        switch (visualElement) {

            // BIG PICTURES

            case PIC_LOGO:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.BLACK,
                        Color.DARKSLATEGRAY, Color.SANDYBROWN, Color.RED, Color.YELLOW};
                data = ImageCreator.decode("c2mp41pawdgb4lpt564n4960z6nu7mb31zrhnpq97wy0iad9rhqeaalhqlalltcp" +
                        "n0dku79n0oegfx2djwsferl7k9n7j6tkxzyq97kukjd2s8ldry903z91ad26kliwv2namjd1gb8ydo8c5uokipt96o" +
                        "vlyoiyi3f61xd4i40w09emhl2cmci82tsuutx8yocnbtkixj8kg8hxq32bsp1e4abwqema98qkydtfc709ntz7selr" +
                        "x3n69btx7ke5szpuncjo9cxtfn1bt18ed5vu1kz887we9waqn68cccfgl6zf49xtv0petektjy4b01xavmcu782cc0" +
                        "eokax3zoi1m4p4iq16r56bskk7ht4vlvqk0koansnl4a6xhqteatk7odz02cjhpseog4khuw8s8cbgs8booztp0xxr" +
                        "8rei0yccz3tyox0gikq03ts7nut4u8tv4plbk02480ajkw4glwx3vpfi5t7hzll939gar1mo7ocrxdae3y37shjc02" +
                        "r547rrgxl35vc9wavjmh91l1h63i6ku7wy6x295wzzfeyebiqlacc75n9y6opc7611hkhd0xwbop80j9qcazolnx2d" +
                        "svpnmuntb1mtwgb2nyyv099bgy1cvnf2fq2519079l279n6ghfzgmkh3k83nj88fx5f97o2wgjw4p5pjsmw25xb150" +
                        "hyyd0etcfm9y9bxzpz293cqjxruecyhb1qzye6h5k2kprjnm4t0al7xqmd6ta87kj2q1xrjrzi58n1509qc3tnqajh" +
                        "ghacha0rz0uraw2u6owtlqz90zwbuy413r2efrsr9ijepuzrija8jucsdvt7xeuyedy7pgdb6g2cjzmuk3gqs6lu6z" +
                        "cgb3ddjzhd9u9yni0dobxo8i3v4fnmt8o9xlr3ito1ljmugz9f2u4de8auff5dxficrly3qrm1tby444lso9uc6q5s" +
                        "27ra3fy35tbxp63u7m30c3gw7a87bxqq4qf9w6jbr7nh3okzrdz91swod8fcebhhyz6egjbrrynhn5i49rsxio61tt" +
                        "csekabgs2orqy3rwaa4cx7al0qzzdfkz7h2e1szl3yy2cysremf3ozhgo105ooorabnthxiwgcs7ntrrpl0oay9653" +
                        "aeggrkx", 32, 68, 7);
                break;
            case PIC_FACE_HAPPY:
                colors = Color.values();
                colors = new Color[]{
                        Color.NONE, Color.values()[1], Color.values()[2], Color.values()[3], Color.values()[4],
                        Color.values()[59], Color.values()[80], Color.values()[126], Color.values()[53]};
                data = ImageCreator.decode("1cybauazcn7fqyn0tvq75tfth1zrnmeh6cuuh5njivjp97fy9a6h6gsyizcvmri2" +
                        "uzir4hv6cj2ilmqrei5saiat2dkinf43cwazsz8d5fg6g5a6s88ntmzngk2jkhns24vxtj", 14, 16, 9);
                break;
            case PIC_FACE_SAD:
                colors = new Color[]{
                        Color.NONE, Color.values()[1], Color.values()[2], Color.values()[3], Color.values()[4],
                        Color.values()[59], Color.values()[80], Color.values()[126], Color.values()[19]};
                data = ImageCreator.decode("1cybauazcn7fqyn0tvq75tfth1zrno7kg365fq2ac1rep009j8p57u69qj16geg1" +
                        "hlwnfm9io159g8ysog529yxphkiku9w5xdyhskm6iouranvhu1nbdjloi0e41b0sxm95p1", 14, 16, 9);
                break;
            case SHOP_ITEM_SHIELD:
                colors = new Color[]{Color.NONE, Color.GRAY, Color.DARKGRAY, Color.DARKSLATEGRAY, Color.DIMGRAY,
                        Color.GAINSBORO, Color.LIGHTSKYBLUE, Color.POWDERBLUE, Color.SILVER, Color.SKYBLUE};
                data = ImageCreator.decode("j48hr0wk806ipsdgoq013o9yrp6eaj1yovoi1b6m67oa7zhasq5otc3jgvtopjlc" +
                        "4uslqc04ry0yal4n14rlogtp6cntje6zscfyrhskcwc5rl4n5rd8zctub3y89pfmf7lj77byzt89dlk72hjfuji6qe" +
                        "tj624gkyntw52v1ugyptaj019qeenwam51y371ts", 18, 18, 10);
                break;
            case SHOP_ITEM_SCANNER:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.RED, Color.GREEN, Color.CHARTREUSE, Color.DARKGREEN,
                        Color.DARKSLATEBLUE, Color.DARKSLATEGREY, Color.FIREBRICK, Color.INDIGO, Color.ORANGERED,
                        Color.SADDLEBROWN, Color.SLATEBLUE};
                data = new int[][]{{0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0xb, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0},
                        {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0},
                        {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0},
                        {0, 0, 0, 1, 1, 7, 7, 7, 7, 7, 7, 7, 7, 1, 1, 0, 0, 0},
                        {0, 0, 0, 1, 1, 7, 5, 5, 5, 5, 5, 5, 7, 1, 1, 0, 0, 0},
                        {0, 0, 0, 9, 1, 7, 3, 2, 3, 3, 3, 3, 7, 1, 9, 0, 0, 0},
                        {0, 0, 0, 9, 1, 7, 5, 5, 5, 5, 5, 4, 7, 1, 9, 0, 0, 0},
                        {0, 0, 0, 9, 1, 7, 3, 3, 3, 3, 4, 3, 7, 1, 9, 0, 0, 0},
                        {0, 0, 0, 9, 1, 7, 5, 5, 5, 4, 5, 5, 7, 1, 9, 0, 0, 0},
                        {0, 0, 0, 9, 1, 7, 3, 3, 3, 3, 3, 3, 7, 1, 9, 0, 0, 0},
                        {0, 0, 0, 1, 1, 1, 7, 7, 7, 7, 7, 7, 1, 1, 1, 0, 0, 0},
                        {0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0},
                        {0, 0, 0, 1, 1, 6, 0xc, 1, 0xa, 0xa, 1, 0xc, 6, 1, 1, 0, 0, 0},
                        {0, 0, 0, 1, 1, 1, 1, 1, 8, 8, 1, 1, 1, 1, 1, 0, 0, 0},
                        {0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0},
                        {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0}};
                break;
            case SHOP_ITEM_FLAG:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.RED, Color.DARKRED, Color.YELLOW};
                data = ImageCreator.decode("jju0bbjetx3u285algtck0jj14cuw5skxzgaotgtqjfcueoota40vrfryeujd3x" +
                        "wtfgyqsxwyr38md54hcf7bjuk73f2gj68f2cyrc2zd6xmvdte8vzhuy30rzfjelucygncxo0s636", 18, 18, 5);
                break;
            case SHOP_ITEM_SHOVEL:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.YELLOW,
                        Color.ORANGE, Color.GOLD, Color.SADDLEBROWN, Color.SIENNA};
                data = ImageCreator.decode("3g5veas1jz42njh35zfryj465tse1dd3ghqhrqq22ijj5pgij9wlyr6w8829u7bg" +
                                "gnq4tpg5axib8s80ndr814e6763blu7q6iwdokww2g35iw8zok3bh06f7wnvjwaxn29nf0nwv939137fvd" +
                                "ue6z8h",
                        18, 18, 7);
                break;
            case SHOP_ITEM_DICE:
                colors = new Color[]{Color.NONE, Color.DARKGRAY, Color.LIGHTGRAY, Color.RED, Color.BLACK};
                data = ImageCreator.decode("4ubg8bfgrmdxdfa9et5lokqklkuhcn7ga0okyl8l4dcgh7zs0fh1px66hok1130" +
                        "6vvv5rvqzg3p9nmg4g07627jzwrq24iipxeqfcdf2wt85zkqmyu81vvhutnxaoj554dxode", 18, 18, 5);
                break;
            case SHOP_ITEM_BOMB:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.GRAY, Color.LIGHTGRAY, Color.RED, Color.YELLOW};
                data = ImageCreator.decode("176000001777600007777700017777760017777760077777870077777770077" +
                        "777770077777770017777d600177787600077777000017j760000019600000000lou0000000500000" +
                        "000uu0", 18, 18, 6);
                break;
            case SHOP_COIN:
                colors = new Color[]{Color.NONE, Color.YELLOW, Color.ORANGE};
                data = ImageCreator.decode("13ynurtl", 6, 4, 3);
                break;
            case MENU_ARROW:
                colors = new Color[]{Color.NONE, Color.YELLOW, Color.WHITE};
                data = ImageCreator.decode("1ktnzk3", 7, 5, 2);
                break;
            case MENU_DIFFICULTY_BAR:
                colors = new Color[]{Color.NONE, Color.GREEN, Color.BLACK};
                data = ImageCreator.decode("18408cx", 7, 3, 3);
                break;
            case WIN_MENU:
                colors = new Color[]{Color.NONE, Theme.MAIN_MENU_BG.getColor(), Color.NONE, Theme.MAIN_MENU_BORDER.getColor()};
                data = ImageCreator.createWindowBitmap(100, 100, false, true);
                break;
            case WIN_SHOP:
                colors = new Color[]{Color.NONE, Theme.SHOP_BG.getColor(), Color.BLACK, Theme.SHOP_BORDER.getColor()};
                data = ImageCreator.createWindowBitmap(80, 80, true, true);
                break;
            case WIN_SHOP_HEADER_FOOTER:
                colors = new Color[]{Color.NONE, Theme.SHOP_HEADER_FOOTER.getColor(), Color.BLACK, Theme.SHOP_BORDER.getColor()};
                data = ImageCreator.createWindowBitmap(80, 12, false, true);
                break;
            case SHOP_ITEM_FRAME:
                colors = new Color[]{Color.NONE, Theme.SHOP_ITEM_BG.getColor(), Color.BLACK, Color.GREEN};
                data = ImageCreator.createWindowBitmap(20, 20, true, true);
                break;
            case SHOP_ITEM_FRAME_PRESSED:
                colors = new Color[]{Color.NONE, Theme.SHOP_ITEM_BG.getColor(), Color.BLACK, Color.GREEN};
                data = ImageCreator.createWindowBitmap(20, 20, false, true);
                break;
            case WIN_VICTORY:
            case WIN_GAME_OVER:
                colors = new Color[]{Color.NONE, Theme.MAIN_MENU_BG.getColor(), Color.BLACK, Theme.BUTTON_BG.getColor()};
                data = ImageCreator.createWindowBitmap(70, 35, true, true);
                break;
            case BUTTON_OK:
                colors = new Color[]{Color.NONE, Color.SADDLEBROWN, Color.BLACK, Color.BURLYWOOD};
                data = ImageCreator.createWindowBitmap(13, 9, true, true);
                break;
            case BUTTON_CLOSE:
                colors = new Color[]{Color.NONE, Color.SADDLEBROWN, Color.BLACK, Color.BURLYWOOD};
                data = ImageCreator.createWindowBitmap(9, 9, true, true);
                break;
            case MENU_SWITCH:
                colors = new Color[]{Color.NONE, Color.RED, Color.BLACK, Color.YELLOW};
                data = ImageCreator.createWindowBitmap(4, 7, false, true);
                break;
            case MENU_SWITCH_RAIL:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.NONE, Color.NONE};
                data = ImageCreator.createWindowBitmap(12, 3, false, false);
                break;
            case WIN_BOARD_TRANSPARENT_FRAME:
                colors = new Color[]{Color.NONE, Color.NONE, Color.NONE, Color.BLUE};
                data = ImageCreator.createWindowBitmap(100, 100, false, true);
                break;
            case MENU_THEME_PALETTE:
                colors = new Color[]{Color.NONE, Color.GRAY, Color.BLACK, Color.WHITE};
                data = ImageCreator.createWindowBitmap(10, 10, false, true);
                break;
            case SHOP_DICE_1:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.RED, Color.BLACK};
                data = ImageCreator.decode("f5kzr1f31tbtpx5cm5br6cqxh", 8, 8, 4);
                break;
            case SHOP_DICE_2:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.BLACK, Color.BLACK};
                data = ImageCreator.decode("f5kzr1f32f7a0zhjhcv1xoxn9", 8, 8, 4);
                break;
            case SHOP_DICE_3:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.BLACK, Color.BLACK};
                data = ImageCreator.decode("f5kzr1f32f7a0zmguxfhc92l1", 8, 8, 4);
                break;
            case SHOP_DICE_4:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.BLACK, Color.BLACK};
                data = ImageCreator.decode("f5kzr1f7dyv8ql7px757r97it", 8, 8, 4);
                break;
            case SHOP_DICE_5:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.BLACK, Color.BLACK};
                data = ImageCreator.decode("f5kzr1f7dyv8qlcnarpn5tcgl", 8, 8, 4);
                break;
            case SHOP_DICE_6:
                colors = new Color[]{Color.NONE, Color.WHITE, Color.BLACK, Color.BLACK};
                data = ImageCreator.decode("f5kzr1f7dyv8qnev1frc6v5ud", 8, 8, 4);
                break;
            case MENU_CUP:
                colors = new Color[]{Color.NONE, Color.GOLD, Color.WHITE, Color.MAROON, Color.KHAKI};
                data = ImageCreator.decode("9dvivkhrwy22ti0gmapjb75z63rl6lrdbqmnldihtq7cogkiy2u00ymiuws37lxt" +
                        "749foapx78fgdb1mfshquzfvqxmbnqnuvsed", 15, 15, 5);
                break;

            // SPRITES

            case SPR_BOARD_0:
                colors = new Color[]{Color.NONE, Color.WHITE};
                data = ImageCreator.decode("em2wck4h1pwb8q874", 10, 10, 2);
                break;
            case SPR_BOARD_1:
                colors = new Color[]{Color.NONE, Color.DARKGREEN};
                data = ImageCreator.decode("10gxnie856eqhjfi0w", 10, 10, 2);
                break;
            case SPR_BOARD_2:
                colors = new Color[]{Color.NONE, Color.DARKBLUE};
                data = ImageCreator.decode("10gofayzpfg985h3b4", 10, 10, 2);
                break;
            case SPR_BOARD_3:
                colors = new Color[]{Color.NONE, Color.DARKRED};
                data = ImageCreator.decode("em2w8n0l7icfsq134", 10, 10, 2);
                break;
            case SPR_BOARD_4:
                colors = new Color[]{Color.NONE, Color.PURPLE};
                data = ImageCreator.decode("t6yp7ij1umjzvadxc", 10, 10, 2);
                break;
            case SPR_BOARD_5:
                colors = new Color[]{Color.NONE, Color.DARKSLATEGRAY};
                data = ImageCreator.decode("em2w8n5h0yh7v3g8w", 10, 10, 2);
                break;
            case SPR_BOARD_6:
                colors = new Color[]{Color.NONE, Color.DARKSLATEBLUE};
                data = ImageCreator.decode("elwqnse0flq92flds", 10, 10, 2);
                break;
            case SPR_BOARD_7:
                colors = new Color[]{Color.NONE, Color.FORESTGREEN};
                data = ImageCreator.decode("elhcfwp4m4qfxgveo", 10, 10, 2);
                break;
            case SPR_BOARD_8:
                colors = new Color[]{Color.NONE, Color.RED};
                data = ImageCreator.decode("elwqns94fvclf3o5c", 10, 10, 2);
                break;
            case SPR_BOARD_9:
                data = ImageCreator.decode("h1hmy8varpmtbkwe8", 10, 10, 2);
                break;
            case SPR_BOARD_FLAG:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.RED, Color.DARKRED, Color.YELLOW};
                data = ImageCreator.decode("gpru22rvevf9lpo0cv2pcjxgcbjmac1rw", 10, 10, 5);
                break;
            case SPR_BOARD_MINE:
                colors = new Color[]{Color.NONE, Color.BLACK, Color.RED, Color.DARKGRAY, Color.DARKSLATEGRAY, Color.DARKRED, Color.DIMGRAY};
                data = ImageCreator.decode("1l9zon7kv9oo00yznw0jssv73kxkz5f9u4bpv14r97q79gpw6m7y0", 10, 10, 7);
                break;

            //TILES

            case CELL_CLOSED:
                colors = new Color[]{Color.NONE, Theme.CELL_SHADOW.getColor(),
                        Theme.CELL_LIGHT.getColor(), Theme.CELL_BG_UP.getColor(), Color.BLACK, Color.GRAY};
                data = ImageCreator.decode("777789lllk9lllk9lllk9lllk9lllk9lllk9lllk9lllkeeeee", 10, 10, 6);
                break;
            case CELL_OPENED:
                colors = new Color[]{Color.NONE, Theme.CELL_SHADOW.getColor(),
                        Theme.CELL_LIGHT.getColor(), Theme.CELL_BG_UP.getColor(), Color.BLACK, Color.GRAY};
                data = ImageCreator.decode("llll8llll8llll8llll8llll8llll8llll8llll877778eeeee", 10, 10, 6);
                break;
            case CELL_DESTROYED:
                colors = new Color[]{Color.NONE, Theme.CELL_SHADOW.getColor(),
                        Theme.CELL_LIGHT.getColor(), Theme.CELL_BG_UP.getColor(), Color.BLACK, Color.GRAY};
                data = ImageCreator.decode("lxln8lxlx8ztmx8lxxx8nmtt8mmrn8nnmx8xnln877778eeeee", 10, 10, 6);
                break;

            // SYMBOLS

            case SYM_RU_LETTER_A:
                data = ImageCreator.decode("2o4idc", 7, 4, 2);
                break;
            case SYM_RU_LETTER_B:
                data = ImageCreator.decode("23tfk0", 7, 4, 2);
                break;
            case SYM_RU_LETTER_V:
                data = ImageCreator.decode("23u39c", 7, 4, 2);
                break;
            case SYM_RU_LETTER_G:
                data = ImageCreator.decode("6fgg", 7, 3, 2);
                break;
            case SYM_RU_LETTER_D:
                data = ImageCreator.decode("7vsf5ssg", 8, 5, 2);
                break;
            case SYM_RU_LETTER_YE:
                data = ImageCreator.decode("46qdxc", 7, 4, 2);
                break;
            case SYM_RU_LETTER_YO:
                data = ImageCreator.decode("46qdxh", 7, 4, 2);
                break;
            case SYM_RU_LETTER_J:
                data = ImageCreator.decode("aotj37k", 7, 5, 2);
                break;
            case SYM_RU_LETTER_Z:
                data = ImageCreator.decode("2364g0", 7, 4, 2);
                break;
            case SYM_RU_LETTER_I:
                data = ImageCreator.decode("2pao00", 7, 4, 2);
                break;
            case SYM_RU_LETTER_IKR:
                data = ImageCreator.decode("2pao06", 7, 4, 2);
                break;
            case SYM_RU_LETTER_K:
                data = ImageCreator.decode("2l5f5s", 7, 4, 2);
                break;
            case SYM_RU_LETTER_L:
                data = ImageCreator.decode("2ok2yo", 7, 4, 2);
                break;
            case SYM_RU_LETTER_M:
                data = ImageCreator.decode("8nozqbk", 7, 5, 2);
                break;
            case SYM_RU_LETTER_N:
                data = ImageCreator.decode("2o4iyo", 7, 4, 2);
                break;
            case SYM_RU_LETTER_O:
                data = ImageCreator.decode("1txatc", 7, 4, 2);
                break;
            case SYM_RU_LETTER_P:
                data = ImageCreator.decode("2nw4qo", 7, 4, 2);
                break;
            case SYM_RU_LETTER_R:
                data = ImageCreator.decode("awq9s", 7, 4, 2);
                break;
            case SYM_RU_LETTER_S:
                data = ImageCreator.decode("3wicxs", 7, 4, 2);
                break;
            case SYM_RU_LETTER_T:
                data = ImageCreator.decode("cukg", 7, 3, 2);
                break;
            case SYM_RU_LETTER_U:
                data = ImageCreator.decode("23hgjk", 7, 4, 2);
                break;
            case SYM_RU_LETTER_F:
                data = ImageCreator.decode("276bpj4", 7, 5, 2);
                break;
            case SYM_RU_LETTER_H:
                data = ImageCreator.decode("2nrvuo", 7, 4, 2);
                break;
            case SYM_RU_LETTER_C:
                data = ImageCreator.decode("7fzlmxhc", 8, 5, 2);
                break;
            case SYM_RU_LETTER_CH:
                data = ImageCreator.decode("2dh1xc", 7, 4, 2);
                break;
            case SYM_RU_LETTER_SHA:
                data = ImageCreator.decode("fmiojr4", 7, 5, 2);
                break;
            case SYM_RU_LETTER_SCHA:
                data = ImageCreator.decode("1ffhaqavi8", 8, 6, 2);
                break;
            case SYM_RU_LETTER_SOFT:
                data = ImageCreator.decode("23tcsg", 7, 4, 2);
                break;
            case SYM_RU_LETTER_Y:
                data = ImageCreator.decode("yrqbha0w", 7, 6, 2);
                break;
            case SYM_RU_LETTER_HARD:
                data = ImageCreator.decode("76u9ou8", 7, 5, 2);
                break;
            case SYM_RU_LETTER_E:
                data = ImageCreator.decode("23hczk", 7, 4, 2);
                break;
            case SYM_RU_LETTER_YU:
                data = ImageCreator.decode("mfsdqpds", 7, 6, 2);
                break;
            case SYM_RU_LETTER_YA:
                data = ImageCreator.decode("2opmgw", 7, 4, 2);
                break;
            case SYM_EN_LETTER_D:
                data = ImageCreator.decode("23wwe8", 7, 4, 2);
                break;
            case SYM_EN_LETTER_F:
                data = ImageCreator.decode("aw2kg", 7, 4, 2);
                break;
            case SYM_EN_LETTER_G:
                data = ImageCreator.decode("1u29ds", 7, 4, 2);
                break;
            case SYM_EN_LETTER_I:
                data = ImageCreator.decode("14xxc", 7, 3, 2);
                break;
            case SYM_EN_LETTER_J:
                data = ImageCreator.decode("n9lvk", 7, 4, 2);
                break;
            case SYM_EN_LETTER_L:
                data = ImageCreator.decode("144sg", 7, 3, 2);
                break;
            case SYM_EN_LETTER_N:
                data = ImageCreator.decode("2qgt1c", 7, 4, 2);
                break;
            case SYM_EN_LETTER_Q:
                data = ImageCreator.decode("2vds00", 7, 4, 2);
                break;
            case SYM_EN_LETTER_R:
                data = ImageCreator.decode("2lbdog", 7, 4, 2);
                break;
            case SYM_EN_LETTER_S:
                data = ImageCreator.decode("235jpc", 7, 4, 2);
                break;
            case SYM_EN_LETTER_U:
                data = ImageCreator.decode("1txbeo", 7, 4, 2);
                break;
            case SYM_EN_LETTER_V:
                data = ImageCreator.decode("24vubcw", 7, 5, 2);
                break;
            case SYM_EN_LETTER_W:
                data = ImageCreator.decode("8t8kl4w", 7, 5, 2);
                break;
            case SYM_EN_LETTER_X:
                data = ImageCreator.decode("8ji7eo0", 7, 5, 2);
                break;
            case SYM_EN_LETTER_Y:
                data = ImageCreator.decode("21bq3nk", 7, 5, 2);
                break;
            case SYM_EN_LETTER_Z:
                data = ImageCreator.decode("46plhc", 7, 4, 2);
                break;
            case SYM_SYMBOL_DOT:
                data = ImageCreator.decode("1s", 7, 1, 2);
                break;
            case SYM_SYMBOL_COMMA:
                data = ImageCreator.decode("kjk", 8, 2, 2);
                break;
            case SYM_SYMBOL_COLON:
                data = ImageCreator.decode("14", 7, 1, 2);
                break;
            case SYM_SYMBOL_EXCLAMATION:
                data = ImageCreator.decode("2k", 7, 1, 2);
                break;
            case SYM_SYMBOL_QUESTION:
                data = ImageCreator.decode("k8cn4", 7, 4, 2);
                break;
            case SYM_SYMBOL_SLASH:
                data = ImageCreator.decode("6iw0", 7, 3, 2);
                break;
            case SYM_SYMBOL_DASH:
                data = ImageCreator.decode("lc", 7, 2, 2);
                break;
            case SYM_SYMBOL_EQUALS:
                data = ImageCreator.decode("2io", 7, 2, 2);
                break;
            case SYM_SYMBOL_ASTERISK:
                data = ImageCreator.decode("3qps", 7, 3, 2);
                break;
            case SYM_SYMBOL_SPACE:
                data = ImageCreator.decode("0", 7, 3, 2);
                break;
            case SYM_SYMBOL_NEWLINE:
                data = ImageCreator.decode("0", 1, 1, 2);
                break;
            case SYM_DIGIT_0:
                data = ImageCreator.decode("17cg0", 7, 3, 2);
                break;
            case SYM_DIGIT_1:
                data = ImageCreator.decode("14xq8", 7, 3, 2);
                break;
            case SYM_DIGIT_2:
                data = ImageCreator.decode("14p8g", 7, 3, 2);
                break;
            case SYM_DIGIT_3:
                data = ImageCreator.decode("16t34", 7, 3, 2);
                break;
            case SYM_DIGIT_4:
                data = ImageCreator.decode("pykg", 7, 3, 2);
                break;
            case SYM_DIGIT_5:
                data = ImageCreator.decode("16rwg", 7, 3, 2);
                break;
            case SYM_DIGIT_6:
                data = ImageCreator.decode("17h6o", 7, 3, 2);
                break;
            case SYM_DIGIT_7:
                data = ImageCreator.decode("posg", 7, 3, 2);
                break;
            case SYM_DIGIT_8:
                data = ImageCreator.decode("17irk", 7, 3, 2);
                break;
            case SYM_DIGIT_9:
                data = ImageCreator.decode("16thc", 7, 3, 2);
                break;
            case SPR_BOARD_NONE:
            case NONE:
            default:
                colors = new Color[]{Color.NONE, Color.WHITE};
                data = new int[1][1];
                break;
        }
    }

    public Color[] getColors() {
        return colors == null ? new Color[]{Color.NONE, Color.WHITE} : colors;
    }

    public int[][] getData() {
        return data;
    }
}